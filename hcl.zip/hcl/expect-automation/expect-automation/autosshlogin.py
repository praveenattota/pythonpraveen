import pexpect
import getpass
import time

def get_credit():
    hostname = raw_input('Enter the hostname :')
    username = raw_input('Enter the username :')
    password = getpass.getpass('Enter the password :')
    return hostname, username, password

#hostname, username, password = get_credit()
hostname, username, password = '192.168.1.1', 'admin', 'hcltech'

ssh = pexpect.spawn('/bin/ssh', ["{}@{}".format(username, hostname)])

ssh.logfile = open('ssh.log', 'w')

ssh.expect('word')
ssh.sendline(password) 

ssh.expect('TRAINING-SWITCH>')
ssh.sendline('enable')

ssh.expect('word')
ssh.sendline('cisco') 

prompt = 'SWITCH#'
ssh.expect(prompt)
ssh.sendline('terminal length 0')

ssh.expect(prompt)
ssh.sendline('show ip interface brief')

ssh.expect(prompt)
#print ssh.before
open('interface.dat', 'w').write(ssh.before)

ssh.sendline(r'show interface FastEthernet1/0/1')

ssh.expect(prompt)
open('interfaceinfo.dat', 'w').write(ssh.before)


with open('interfaceinfo.dat') as fp:
    for line in fp:
        if 'reliability' in line:
            print line.rstrip()
            break

ssh.terminate()
