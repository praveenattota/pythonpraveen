a = input('Enter the value1 :')
b = input('Enter the value2 :')

res = a + b
print "sumation : {}".format(res)

