__author__ = 'ravi'
from time import sleep
import pexpect
child = pexpect.spawn('/usr/bin/python', ['guessme.py'])
child.log
chance = 1
start = 1
end = 1000

def get_mid():
    return (start + end)/2

while chance <= 10:
    sleep(1)
    print "Chance : {}".format(chance)
    child.expect("guess:")
    mid = get_mid()
    print "Sending : {}".format(mid)
    child.sendline(str(mid))
    return_index = child.expect(['greater', 'lesser', 'won', 'lost',
                                        pexpect.EOF, pexpect.TIMEOUT])
    if return_index == 0:
        end = mid
    elif return_index == 1:
        start = mid
    elif return_index == 2:
        print "expect won"
        break
    elif return_index == 3:
        print "expect lost"
        break
    chance += 1

child.expect(pexpect.EOF)
