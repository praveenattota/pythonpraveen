__author__ = 'ravi'
import random
max_chance = 10

def do_play():
    chance = 1
    rand_value = random.randint(1, 1000)
    while chance <= max_chance:
        try:
            value = input('change : {}\nEnter the guess:'.
                              format(chance))

            if value == rand_value:
                print "You won :) !!!!!!!!!"
                break
            elif value < rand_value:
                    print "{}: entered value was lesser".format(value)
            elif value > rand_value:
                print "{}: entered value was greater".format(value)
            chance += 1
            print
        except:
                pass
    else:
        print "you lost, looser, :(............. "
        exit(1)

do_play()