import pexpect
import re
import time
logname = "add{}.log".format(time.strftime('%d%b%Y%H%M%S'))

c = pexpect.spawn('/usr/bin/python', ["add.py"], timeout=5)
c.setecho(False)

c.logfile = open(logname, 'w')

c.expect('value1')
c.sendline('10')

c.expect('value2')
c.sendline('20')


c.expect(pexpect.EOF)
for line in c.before.split('\n'):
    if re.search('sum', line, re.I):
        print line

