import pdb
import os

for count, char in enumerate('this is a sample string', 1):
    if count == 10:
        pdb.set_trace()

    print count, char