nums = range(1, 55)

print map (lambda n: n%7 == 0, nums)