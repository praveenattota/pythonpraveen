l1 = [1, 2,3,4,5]
l2 = [1,2,3,4,5]
l3 = [2,1,3,4,5]
print id(l1[0])
print id(l2[0])
print id(l3[1])