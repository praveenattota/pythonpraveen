from math import pi

radius = 7.890
area = pi * (radius ** 2)

content = "radius : %s\narea : %.3f" % (radius, area)  # string formatter
print content.upper()

# 5 % (3, 2)
