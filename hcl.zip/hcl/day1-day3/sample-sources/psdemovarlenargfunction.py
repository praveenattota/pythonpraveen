def demo(*args):
    print args


demo()
demo('peter')
demo(1, 2, 3, 4, 5, 'size')

"""
l = ("a", 'e', 'i', 'o')
demo(l)
demo(*l)
"""