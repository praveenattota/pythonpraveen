def demo():
    global n #reference global version n
    n = 123  #local
    print n

demo()
print n