def file_copy(src_file, target_file):
    with open(src_file) as fp, open(target_file, 'w') as fw:
        fw.write(fp.read())

file_copy('passwd.txt', 'testit')