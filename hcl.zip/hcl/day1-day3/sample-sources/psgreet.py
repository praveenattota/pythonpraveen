#!/usr/bin/env python
# a sample script

name = "hp"
city = 'ny'

print 'name :', name
print 'city :', city
