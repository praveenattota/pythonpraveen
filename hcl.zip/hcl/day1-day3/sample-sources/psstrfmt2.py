name, age, gender = 'sara', 4, 'female'  #parallel assignment

print "|{}|{}|{}|".format(name, age, gender)
print "|{:>22}|{:>5}|{:>16}|".format(name, age, gender)
print "|{:<22}|{:<5}|{:<16}|".format(name, age, gender)
print "|{:^22}|{:^5}|{:^16}|".format(name, age, gender)
print "|{:22}|{:5.2f}|{:16}|".format(name, age, gender)

l = ["pam", 3, "female", 3, 4, 5]
fmt_str = "{:>22}" * len(l)
print fmt_str.format(*l)