with open('passwd.txt') as fp:
    try:
        fp.write("a sample content")
    except IOError, e:
        print fp.closed
        pass

print fp

