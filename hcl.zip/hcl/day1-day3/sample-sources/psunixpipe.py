import subprocess

cat = subprocess.Popen(['cat', '/etc/passwd'], stdout=subprocess.PIPE)
print cat.stdout.read()
tr = subprocess.Popen(['tr', 'a-z', 'A-Z'], stdin=cat.stdout,
                      stdout=subprocess.PIPE)

head = subprocess.Popen(['head', '-n', '3'], stdin=tr.stdout,
                        stdout=subprocess.PIPE)


for line in head.communicate():
    if line:
        print line,