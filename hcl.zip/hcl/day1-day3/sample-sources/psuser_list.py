def get_user_list(data_file):
    user_list = list()

    with open(data_file) as fp:
        for line in fp:
            if line.startswith('#'):
                continue
                
            login = line.split(':')[0]

            '''if login.startswith('_'):
                login = login.replace('_', '', 1)
            '''
            user_list.append(login.title())

    for line_no, user in enumerate(sorted(user_list), 1):
        print "{:>6}  {}".format(line_no, user)

get_user_list('passwd.txt')