import paramiko
import os
private_key_file = os.path.expanduser('~/.ssh/id_rsa')
private_key_object = paramiko.RSAKey.from_private_key_file(private_key_file)

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('localhost', username = 'tester', pkey = private_key_object)
(i, o, e) = ssh.exec_command('whoami')
print o.read()