def compute_bill(units):
    billable = 0

    if units <= 100:
        billable = units
    elif units <= 200:
        billable = units * 1.5
    elif units <= 500:
        billable = 400 + (units - 200) * 3
    elif units > 500:
        billable = 1800 + (units - 500) * 5.75

    return billable

try:
    consumed = int(raw_input('enter the units :'))
    billable_amt = compute_bill(consumed)
    print "billable : {:.2f}".format(billable_amt)
except ValueError, e:
    print e