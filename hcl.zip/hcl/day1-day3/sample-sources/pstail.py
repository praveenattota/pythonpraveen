from collections import deque as deq

for line in deq(open('/etc/passwd'), 4):
    print line,