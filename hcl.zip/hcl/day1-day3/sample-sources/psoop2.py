class Demo(object):
    def __init__(self):
        print self, "am in constructor"

    def __del__(self):
        print self, "am getting destoryed"

d = Demo()
print d
print type(Demo)
