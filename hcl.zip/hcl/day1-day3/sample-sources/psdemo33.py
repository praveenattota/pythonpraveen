l = [1, 2, 'iii', 4.0]
backup = l  #shallow copy

del l[-1]
l[0] = 'one'

print l
print backup