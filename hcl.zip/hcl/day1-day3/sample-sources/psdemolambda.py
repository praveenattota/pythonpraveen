from pprint import pprint as pp


l = [4, 3, 5, 6, 7]

# temp = map(hex, l)
# print temp

ascii = map(ord, 'peter')
print ascii
'''
[112, 101, 116, 101, 114]
['<ascii char="p">112</ascii>', ]
'''


def tag_it(as_v):
    return '<ascii char="{}">{}</ascii>'.format(chr(as_v), as_v)

# tags = map(tag_it, ascii)
tags = map(lambda as_v:
           '<ascii char="{}">{}</ascii>'.format(chr(as_v), as_v), ascii
           )
pp(tags)