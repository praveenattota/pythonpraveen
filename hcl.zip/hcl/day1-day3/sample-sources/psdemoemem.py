from sys import getrefcount
a = 100
b = 100
c = 100
n = 100
print id(a)
print id(c)
print id(b)
print id(n)
print getrefcount(100)