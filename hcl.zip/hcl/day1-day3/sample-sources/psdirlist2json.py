from psdirectorylisting import DirectoryListing
from json import dump


class DirectoryListing2JSON(DirectoryListing):

    def __init__(self, *directories, **kwargs):
        super(DirectoryListing2JSON, self).__init__(*directories)
        self.json_file = kwargs.get('json_file', None)

    def to_json(self, json_file=None):
        if json_file:
            self.json_file = json_file

        dump(self.container, open(self.json_file, 'w'), indent=4)

if __name__ == '__main__':
    DirectoryListing2JSON('/home/ravi/rootcap',
                         '/training/ravi/Training',
                          json_file='temp.json').to_json()