def power(x, n=0):
    return x ** n

print power(5, 4)
print power(5)
print power
print type(power)